#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/BEEP/beep.h"
#include "./BSP/KEY/key.h"
#include "./BSP/KEY/gtim.h"

extern int t,time;
int main(void)
{
    uint8_t key;
    
    HAL_Init();                             /* ��ʼ��HAL�� */
    sys_stm32_clock_init(336, 8, 2, 7);     /* ����ʱ��,168Mhz */
    delay_init(168);                        /* ��ʱ��ʼ�� */
    led_init();                             /* ��ʼ��LED */
    usart_init(115200);
    gtim_timx_int_init(10 - 1, 8400 - 1); /* ����Ϊ1ms���һ�� */
    key_init();                             /* ��ʼ������ */

    while(1)
    {
        key = key_scan_1(KEY0_GPIO_PORT, KEY0_GPIO_PIN);                  /* �õ���ֵ */
        if (key)
        {
            switch (key)
            {
                case click:             /* ����LED0(RED)��ת */
                    LED1_TOGGLE();          /* LED0״̬ȡ�� */
                    break;
                
//                case double_click:             /* ����LED1(GREEN)��ת */
//                    LED1_TOGGLE();          /* LED1״̬ȡ�� */
//                    break;
                
                case Long_press:             /* ͬʱ����LED0, LED1��ת */
                    LED0_TOGGLE();          /* LED0״̬ȡ�� */
                    break;

                default : break;
            }
        }
        else
        {
            if(t == 200)
            {
                t = 0;
                LED0_TOGGLE();
            }
        }
    }
}

